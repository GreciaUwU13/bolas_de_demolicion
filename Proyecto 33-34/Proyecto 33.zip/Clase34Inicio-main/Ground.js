class Ground {
    constructor (x, y, width, height){
       
    }

    display(){
       
    }
};